function preload() {
    j = loadSound("Juice.mp3")
    h = loadSound("Humble.mp3")
    g = loadSound("Goosebumps.mp3")
}

function setup() {
}
function mouseClicked() {

}